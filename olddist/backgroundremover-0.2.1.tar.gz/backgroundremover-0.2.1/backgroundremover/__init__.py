"""
backgroundremover

A library to remove background from videos and images
"""

__version__ = "0.1.9"
__author__ = 'Johnathan Nader'
__credits__ = 'BackgroundRemover.app'
