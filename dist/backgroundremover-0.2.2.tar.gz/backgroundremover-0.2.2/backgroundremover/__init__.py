"""
backgroundremover

A library to remove background from videos and images
"""

__version__ = "0.2.2"
__author__ = 'Johnathan Nader'
__credits__ = 'BackgroundRemoverAI.com'
